class Guest:
    def __init__(self, name: str, email: str):
        self.name = name
        self.email = email
