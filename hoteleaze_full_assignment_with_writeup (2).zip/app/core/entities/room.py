class Room:
    def __init__(self, name: str, capacity: int):
        self.name = name
        self.capacity = capacity
