class Booking:
    def __init__(self, guest_id: str, room_id: str, date: str):
        self.guest_id = guest_id
        self.room_id = room_id
        self.date = date
