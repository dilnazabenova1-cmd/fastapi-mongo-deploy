
from app.adapters.repository.room_repo import RoomRepo

class RoomUseCase:
    @staticmethod
    def create_room(data):
        return RoomRepo.create(data)

    @staticmethod
    def list_rooms():
        return RoomRepo.get_all()

    @staticmethod
    def get_room(id: str):
        return RoomRepo.get(id)

    @staticmethod
    def delete_room(id: str):
        return RoomRepo.delete(id)
