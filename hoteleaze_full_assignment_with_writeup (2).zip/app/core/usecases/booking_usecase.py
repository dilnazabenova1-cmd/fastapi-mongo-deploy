
from app.adapters.repository.booking_repo import BookingRepo

class BookingUseCase:
    @staticmethod
    def create_booking(data):
        return BookingRepo.create(data)

    @staticmethod
    def list_bookings():
        return BookingRepo.get_all()

    @staticmethod
    def get_booking(id: str):
        return BookingRepo.get(id)

    @staticmethod
    def delete_booking(id: str):
        return BookingRepo.delete(id)
