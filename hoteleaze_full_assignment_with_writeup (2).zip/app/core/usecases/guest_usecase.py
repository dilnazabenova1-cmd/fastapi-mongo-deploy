
from app.adapters.repository.guest_repo import GuestRepo

class GuestUseCase:
    @staticmethod
    def create_guest(data):
        return GuestRepo.create(data)

    @staticmethod
    def list_guests():
        return GuestRepo.get_all()

    @staticmethod
    def get_guest(id: str):
        return GuestRepo.get(id)

    @staticmethod
    def delete_guest(id: str):
        return GuestRepo.delete(id)
