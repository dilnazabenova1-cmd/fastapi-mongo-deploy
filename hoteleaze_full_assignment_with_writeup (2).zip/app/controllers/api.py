
from fastapi import APIRouter
from app.core.usecases.room_usecase import RoomUseCase
from app.core.usecases.guest_usecase import GuestUseCase
from app.core.usecases.booking_usecase import BookingUseCase

router = APIRouter()

# Rooms endpoints
@router.post("/rooms")
def create_room(room: dict):
    return {"id": RoomUseCase.create_room(room)}

@router.get("/rooms")
def get_rooms():
    return RoomUseCase.list_rooms()

@router.get("/rooms/{room_id}")
def get_room(room_id: str):
    return RoomUseCase.get_room(room_id)

@router.delete("/rooms/{room_id}")
def delete_room(room_id: str):
    return {"deleted": RoomUseCase.delete_room(room_id)}

# Guests endpoints
@router.post("/guests")
def create_guest(guest: dict):
    return {"id": GuestUseCase.create_guest(guest)}

@router.get("/guests")
def get_guests():
    return GuestUseCase.list_guests()

@router.get("/guests/{guest_id}")
def get_guest(guest_id: str):
    return GuestUseCase.get_guest(guest_id)

@router.delete("/guests/{guest_id}")
def delete_guest(guest_id: str):
    return {"deleted": GuestUseCase.delete_guest(guest_id)}

# Bookings endpoints
@router.post("/bookings")
def create_booking(booking: dict):
    return {"id": BookingUseCase.create_booking(booking)}

@router.get("/bookings")
def get_bookings():
    return BookingUseCase.list_bookings()

@router.get("/bookings/{booking_id}")
def get_booking(booking_id: str):
    return BookingUseCase.get_booking(booking_id)

@router.delete("/bookings/{booking_id}")
def delete_booking(booking_id: str):
    return {"deleted": BookingUseCase.delete_booking(booking_id)}
