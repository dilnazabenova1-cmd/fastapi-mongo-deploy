
from app.adapters.database.mongo import db

class RoomRepo:
    collection = db["rooms"]

    @staticmethod
    def create(room: dict):
        result = RoomRepo.collection.insert_one(room)
        return str(result.inserted_id)

    @staticmethod
    def get_all():
        return list(RoomRepo.collection.find({}, {"_id": 0}))

    @staticmethod
    def get(id: str):
        return RoomRepo.collection.find_one({"id": id}, {"_id": 0})

    @staticmethod
    def delete(id: str):
        result = RoomRepo.collection.delete_one({"id": id})
        return result.deleted_count
