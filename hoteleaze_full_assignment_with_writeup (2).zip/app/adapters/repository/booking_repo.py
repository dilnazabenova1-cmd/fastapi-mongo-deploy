
from app.adapters.database.mongo import db

class BookingRepo:
    collection = db["bookings"]

    @staticmethod
    def create(booking: dict):
        result = BookingRepo.collection.insert_one(booking)
        return str(result.inserted_id)

    @staticmethod
    def get_all():
        return list(BookingRepo.collection.find({}, {"_id": 0}))

    @staticmethod
    def get(id: str):
        return BookingRepo.collection.find_one({"id": id}, {"_id": 0})

    @staticmethod
    def delete(id: str):
        result = BookingRepo.collection.delete_one({"id": id})
        return result.deleted_count
