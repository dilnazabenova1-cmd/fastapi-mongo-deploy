
from app.adapters.database.mongo import db

class GuestRepo:
    collection = db["guests"]

    @staticmethod
    def create(guest: dict):
        result = GuestRepo.collection.insert_one(guest)
        return str(result.inserted_id)

    @staticmethod
    def get_all():
        return list(GuestRepo.collection.find({}, {"_id": 0}))

    @staticmethod
    def get(id: str):
        return GuestRepo.collection.find_one({"id": id}, {"_id": 0})

    @staticmethod
    def delete(id: str):
        result = GuestRepo.collection.delete_one({"id": id})
        return result.deleted_count
