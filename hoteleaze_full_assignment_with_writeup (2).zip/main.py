
from fastapi import FastAPI
from app.controllers.api import router as api_router

app = FastAPI(title="HotelEase Microservice")
app.include_router(api_router, prefix="/api")

@app.get("/health")
def health():
    return {"status": "ok"}

@app.get("/health/db")
def health_db():
    from app.adapters.database.mongo import test_db
    return {"db_status": test_db()}
